add jar ../../../target/json-serde-1.0-SNAPSHOT-jar-with-dependencies.jar;

SELECT * from json_test1;

